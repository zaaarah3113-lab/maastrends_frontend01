/**
 * Shopping Cart Module
 * Uses localStorage for persistence — no login required
 */

const CART_STORAGE_KEY = 'maastrends_cart';

/** @type {Array} */
let cart = [];

/**
 * Load cart from localStorage
 */
function loadCart() {
  try {
    const stored = localStorage.getItem(CART_STORAGE_KEY);
    cart = stored ? JSON.parse(stored) : [];
  } catch {
    cart = [];
  }
  updateCartUI();
}

/**
 * Save cart to localStorage
 */
function saveCart() {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  updateCartUI();
}

/**
 * Add item to cart
 * @param {Object} item - { id, name, price, size, quantity, image }
 */
function addToCart(item) {
  const existing = cart.find(
    c => c.id === item.id && c.size === item.size
  );

  if (existing) {
    existing.quantity += item.quantity;
  } else {
    cart.push({ ...item });
  }

  saveCart();
  showToast(`${item.name} added to cart`);
}

/**
 * Remove item from cart by index
 * @param {number} index
 */
function removeFromCart(index) {
  cart.splice(index, 1);
  saveCart();
}

/**
 * Get cart items
 * @returns {Array}
 */
function getCartItems() {
  return cart;
}

/**
 * Get cart total amount
 * @returns {number}
 */
function getCartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

/**
 * Get total item count
 * @returns {number}
 */
function getCartCount() {
  return cart.reduce((sum, item) => sum + item.quantity, 0);
}

/**
 * Clear cart after successful order
 */
function clearCart() {
  cart = [];
  saveCart();
}

/**
 * Update cart badge count and sidebar contents
 */
function updateCartUI() {
  const countEl = document.getElementById('cartCount');
  const itemsEl = document.getElementById('cartItems');
  const emptyEl = document.getElementById('cartEmpty');
  const footerEl = document.getElementById('cartFooter');
  const totalEl = document.getElementById('cartTotal');

  const count = getCartCount();

  if (countEl) {
    countEl.textContent = count;
    if (count > 0) {
      countEl.classList.add('bump');
      setTimeout(() => countEl.classList.remove('bump'), 300);
    }
  }

  if (!itemsEl) return;

  if (cart.length === 0) {
    emptyEl.hidden = false;
    itemsEl.innerHTML = '';
    footerEl.hidden = true;
    return;
  }

  emptyEl.hidden = true;
  footerEl.hidden = false;

  itemsEl.innerHTML = cart.map((item, index) => `
    <li class="cart-item">
      <img class="cart-item__image" src="${item.image}" alt="${item.name}" loading="lazy">
      <div class="cart-item__info">
        <p class="cart-item__name">${item.name}</p>
        <p class="cart-item__meta">Size: ${item.size} · Qty: ${item.quantity}</p>
        <p class="cart-item__price">${formatPrice(item.price * item.quantity)}</p>
        <button class="cart-item__remove" data-remove-index="${index}">Remove</button>
      </div>
    </li>
  `).join('');

  if (totalEl) {
    totalEl.textContent = formatPrice(getCartTotal());
  }

  // Bind remove buttons
  itemsEl.querySelectorAll('[data-remove-index]').forEach(btn => {
    btn.addEventListener('click', () => {
      removeFromCart(parseInt(btn.dataset.removeIndex, 10));
    });
  });
}

/**
 * Open cart sidebar
 */
function openCart() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartOverlay');
  sidebar.hidden = false;
  overlay.hidden = false;
  requestAnimationFrame(() => {
    sidebar.classList.add('open');
    overlay.classList.add('visible');
  });
  document.body.style.overflow = 'hidden';
}

/**
 * Close cart sidebar
 */
function closeCart() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartOverlay');
  sidebar.classList.remove('open');
  overlay.classList.remove('visible');
  document.body.style.overflow = '';
  setTimeout(() => {
    sidebar.hidden = true;
    overlay.hidden = true;
  }, 300);
}

/**
 * Initialize cart event listeners
 */
function initCart() {
  loadCart();

  document.getElementById('cartBtn')?.addEventListener('click', openCart);
  document.getElementById('cartClose')?.addEventListener('click', closeCart);
  document.getElementById('cartOverlay')?.addEventListener('click', closeCart);
  document.getElementById('cartCheckoutBtn')?.addEventListener('click', () => {
    closeCart();
    openCheckout();
  });
}
