/**
 * Checkout & Order Confirmation Module
 */

/** @type {Object|null} Current checkout item for Buy Now flow */
let buyNowItem = null;

/** Shipping cost */
const SHIPPING_COST = 99;

/**
 * Generate unique order ID
 * @returns {string}
 */
function generateOrderId() {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `MT-${timestamp}-${random}`;
}

/**
 * Open checkout modal
 * @param {Object|null} singleItem - For Buy Now, pass a single cart item
 */
function openCheckout(singleItem) {
  buyNowItem = singleItem || null;
  const modal = document.getElementById('checkoutModal');
  renderOrderSummary();
  updatePaymentAmount();
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}

/**
 * Close checkout modal
 */
function closeCheckout() {
  const modal = document.getElementById('checkoutModal');
  modal.hidden = true;
  buyNowItem = null;
  if (!isAnyModalOpen()) {
    document.body.style.overflow = '';
  }
}

/**
 * Get items for current checkout session
 * @returns {Array}
 */
function getCheckoutItems() {
  return buyNowItem ? [buyNowItem] : getCartItems();
}

/**
 * Render order summary in checkout modal
 */
function renderOrderSummary() {
  const summaryEl = document.getElementById('orderSummary');
  const items = getCheckoutItems();

  if (!items.length) {
    summaryEl.innerHTML = '<p>No items in order.</p>';
    return;
  }

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + SHIPPING_COST;

  const itemsHtml = items.map(item => `
    <div class="order-summary__item">
      <div>
        <div class="order-summary__item-name">${item.name}</div>
        <div class="order-summary__item-meta">Size: ${item.size} · Qty: ${item.quantity}</div>
      </div>
      <span>${formatPrice(item.price * item.quantity)}</span>
    </div>
  `).join('');

  summaryEl.innerHTML = `
    ${itemsHtml}
    <div class="order-summary__row">
      <span>Subtotal</span>
      <span>${formatPrice(subtotal)}</span>
    </div>
    <div class="order-summary__row">
      <span>Shipping</span>
      <span>${formatPrice(SHIPPING_COST)}</span>
    </div>
    <div class="order-summary__total">
      <span>Total</span>
      <span>${formatPrice(total)}</span>
    </div>
  `;
}

/**
 * Update payment amount display
 */
function updatePaymentAmount() {
  const items = getCheckoutItems();
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + SHIPPING_COST;
  const amountEl = document.getElementById('paymentAmount');
  if (amountEl) amountEl.textContent = formatPrice(total);
}

/**
 * Validate checkout form fields
 * @param {HTMLFormElement} form
 * @returns {boolean}
 */
function validateCheckoutForm(form) {
  let valid = true;
  const requiredFields = form.querySelectorAll('[required]');

  requiredFields.forEach(field => {
    if (!field.value.trim()) {
      field.classList.add('error');
      valid = false;
    } else {
      field.classList.remove('error');
    }
  });

  // Email validation
  const email = form.querySelector('#email');
  if (email && email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
    email.classList.add('error');
    valid = false;
  }

  // Mobile validation (basic)
  const mobile = form.querySelector('#mobile');
  if (mobile && mobile.value && !/^[\d\s+\-()]{10,15}$/.test(mobile.value)) {
    mobile.classList.add('error');
    valid = false;
  }

  return valid;
}

/**
 * Collect customer details from form
 * @param {HTMLFormElement} form
 * @returns {Object}
 */
function collectCustomerDetails(form) {
  const fd = new FormData(form);
  return {
    fullName: fd.get('fullName'),
    mobile: fd.get('mobile'),
    email: fd.get('email'),
    houseNo: fd.get('houseNo'),
    street: fd.get('street'),
    area: fd.get('area'),
    city: fd.get('city'),
    state: fd.get('state'),
    postalCode: fd.get('postalCode'),
    country: fd.get('country'),
    landmark: fd.get('landmark') || ''
  };
}

/**
 * Get payment method label
 * @param {string} value
 * @returns {string}
 */
function getPaymentMethodLabel(value) {
  const labels = {
    upi: 'UPI Payment',
    gpay: 'Google Pay (GPay)',
    upi_id: 'UPI ID Payment'
  };
  return labels[value] || value;
}

/**
 * Process order placement
 * @param {HTMLFormElement} form
 */
function placeOrder(form) {
  if (!validateCheckoutForm(form)) {
    showToast('Please fill in all required fields correctly.');
    return;
  }

  const items = getCheckoutItems();
  if (!items.length) {
    showToast('Your cart is empty.');
    return;
  }

  const customer = collectCustomerDetails(form);
  const paymentMethod = form.querySelector('input[name="paymentMethod"]:checked')?.value || 'upi';
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const order = {
    orderId: generateOrderId(),
    date: new Date().toLocaleString('en-IN', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }),
    items: items.map(item => ({ ...item })),
    customer,
    paymentMethod: getPaymentMethodLabel(paymentMethod),
    subtotal,
    shipping: SHIPPING_COST,
    total: subtotal + SHIPPING_COST,
    status: 'confirmed'
  };

  // Future backend integration point:
  // const response = await fetch('/api/orders', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(order)
  // });

  // Store order locally for reference
  try {
    const orders = JSON.parse(localStorage.getItem('maastrends_orders') || '[]');
    orders.push(order);
    localStorage.setItem('maastrends_orders', JSON.stringify(orders));
  } catch { /* silent */ }

  // Trigger WhatsApp confirmation
  sendOrderWhatsAppConfirmation(order);

  // Clear cart if not buy-now-only
  if (!buyNowItem) {
    clearCart();
  }
  buyNowItem = null;

  closeCheckout();
  showOrderConfirmation(order);
  form.reset();
  document.getElementById('country').value = 'India';
}

/**
 * Show order confirmation modal
 * @param {Object} order
 */
function showOrderConfirmation(order) {
  const modal = document.getElementById('confirmationModal');
  const content = document.getElementById('confirmationContent');

  const address = [
    order.customer.houseNo,
    order.customer.street,
    order.customer.area,
    order.customer.city,
    order.customer.state,
    order.customer.postalCode,
    order.customer.country
  ].filter(Boolean).join(', ');

  const itemsHtml = order.items.map(item =>
    `<li>${item.name} — Size: ${item.size}, Qty: ${item.quantity} — ${formatPrice(item.price * item.quantity)}</li>`
  ).join('');

  content.innerHTML = `
    <div class="confirmation__icon">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M20 6L9 17l-5-5"/>
      </svg>
    </div>
    <h2 class="confirmation__title">Order Successful!</h2>
    <p class="confirmation__subtitle">Thank you for shopping with Maas Trends</p>

    <div class="confirmation__whatsapp-msg">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.435 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
      <p>Your order has been placed successfully. You will receive a WhatsApp confirmation message shortly.</p>
    </div>

    <div class="confirmation__section">
      <h4>Order ID</h4>
      <p class="confirmation__order-id">${order.orderId}</p>
    </div>

    <div class="confirmation__section">
      <h4>Order Summary</h4>
      <ul>${itemsHtml}</ul>
      <p style="margin-top: 0.5rem; font-weight: 600;">Total: ${formatPrice(order.total)} (incl. shipping)</p>
      <p>Payment: ${order.paymentMethod} — Confirmed</p>
    </div>

    <div class="confirmation__section">
      <h4>Delivery Details</h4>
      <p><strong>${order.customer.fullName}</strong></p>
      <p>${order.customer.mobile} · ${order.customer.email}</p>
      <p>${address}</p>
      ${order.customer.landmark ? `<p>Landmark: ${order.customer.landmark}</p>` : ''}
    </div>

    <button class="btn btn--primary btn--full" data-close-modal style="margin-top: 1rem;">
      Continue Shopping
    </button>
  `;

  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}

/**
 * Check if any modal is currently open
 * @returns {boolean}
 */
function isAnyModalOpen() {
  return document.querySelectorAll('.modal:not([hidden])').length > 0;
}

/**
 * Initialize checkout module
 */
function initCheckout() {
  const form = document.getElementById('checkoutForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      placeOrder(form);
    });

    // Clear error state on input
    form.querySelectorAll('input, textarea').forEach(field => {
      field.addEventListener('input', () => field.classList.remove('error'));
    });
  }
}
