/**
 * Main Application Module
 * Handles UI rendering, navigation, modals, search, and scroll animations
 */

/** Current active category filter */
let activeCategory = 'all';

/** Current search query */
let searchQuery = '';

/** Currently viewed product in detail modal */
let currentProduct = null;

/** Selected size and quantity in product detail */
let selectedSize = '';
let selectedQuantity = 1;

// ==========================================
// TOAST NOTIFICATIONS
// ==========================================

/**
 * Show a toast notification message
 * @param {string} message
 * @param {number} duration - Display duration in ms
 */
function showToast(message, duration = 3000) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.hidden = false;
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => { toast.hidden = true; }, 300);
  }, duration);
}

// ==========================================
// PRODUCT GRID RENDERING
// ==========================================

/**
 * Render product cards in the grid
 */
function renderProducts() {
  const grid = document.getElementById('productGrid');
  const noResults = document.getElementById('noResults');
  const products = filterProducts(activeCategory, searchQuery);

  if (!products.length) {
    grid.innerHTML = '';
    noResults.hidden = false;
    return;
  }

  noResults.hidden = true;

  grid.innerHTML = products.map(product => `
    <article class="product-card reveal" role="listitem" data-product-id="${product.id}">
      <div class="product-card__image-wrap">
        <img class="product-card__image" src="${product.images[0]}" alt="${product.name}" loading="lazy">
        <span class="product-card__category">${product.categoryLabel}</span>
      </div>
      <div class="product-card__body">
        <h3 class="product-card__name">${product.name}</h3>
        <p class="product-card__desc">${product.description}</p>
        <p class="product-card__sizes">Sizes: ${product.sizes.join(', ')}</p>
        <div class="product-card__footer">
          <span class="product-card__price">${formatPrice(product.price)}</span>
          <button class="btn btn--secondary btn--sm" data-add-cart="${product.id}">
            Add to Cart
          </button>
        </div>
      </div>
    </article>
  `).join('');

  // Bind card click events
  grid.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('[data-add-cart]')) return;
      openProductModal(card.dataset.productId);
    });
  });

  // Bind add-to-cart from card buttons
  grid.querySelectorAll('[data-add-cart]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const product = getProductById(btn.dataset.addCart);
      if (product) {
        addToCart({
          id: product.id,
          name: product.name,
          price: product.price,
          size: product.sizes[0],
          quantity: 1,
          image: product.images[0]
        });
      }
    });
  });

  observeRevealElements();
}

// ==========================================
// PRODUCT DETAIL MODAL
// ==========================================

/**
 * Open product detail modal
 * @param {string} productId
 */
function openProductModal(productId) {
  const product = getProductById(productId);
  if (!product) return;

  currentProduct = product;
  selectedSize = product.sizes[0];
  selectedQuantity = 1;

  const detailEl = document.getElementById('productDetail');
  detailEl.innerHTML = `
    <div class="product-detail__gallery">
      <div class="product-detail__main-image">
        <img id="mainProductImage" src="${product.images[0]}" alt="${product.name}">
      </div>
      ${product.images.length > 1 ? `
        <div class="product-detail__thumbs">
          ${product.images.map((img, i) => `
            <button class="product-detail__thumb ${i === 0 ? 'active' : ''}" data-thumb-index="${i}" aria-label="View image ${i + 1}">
              <img src="${img}" alt="${product.name} thumbnail ${i + 1}">
            </button>
          `).join('')}
        </div>
      ` : ''}
    </div>
    <div class="product-detail__info">
      <span class="product-detail__category">${product.categoryLabel}</span>
      <h2 class="product-detail__title" id="productModalTitle">${product.name}</h2>
      <p class="product-detail__price">${formatPrice(product.price)}</p>
      <p class="product-detail__desc">${product.description}</p>

      <div>
        <p class="product-detail__sizes-label">Select Size</p>
        <div class="size-options" id="sizeOptions">
          ${product.sizes.map(size => `
            <button class="size-option ${size === selectedSize ? 'selected' : ''}" data-size="${size}">${size}</button>
          `).join('')}
        </div>
      </div>

      <div>
        <p class="product-detail__qty-label">Quantity</p>
        <div class="quantity-selector">
          <button type="button" id="qtyDecrease" aria-label="Decrease quantity">−</button>
          <input type="number" id="qtyInput" value="1" min="1" max="10" readonly aria-label="Quantity">
          <button type="button" id="qtyIncrease" aria-label="Increase quantity">+</button>
        </div>
      </div>

      <div class="product-detail__actions">
        <button class="btn btn--primary" id="detailAddToCart">Add to Cart</button>
        <button class="btn btn--gold" id="detailBuyNow">Buy Now</button>
      </div>
    </div>
  `;

  // Thumbnail gallery
  detailEl.querySelectorAll('[data-thumb-index]').forEach(thumb => {
    thumb.addEventListener('click', () => {
      const index = parseInt(thumb.dataset.thumbIndex, 10);
      document.getElementById('mainProductImage').src = product.images[index];
      detailEl.querySelectorAll('.product-detail__thumb').forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
    });
  });

  // Size selection
  detailEl.querySelectorAll('.size-option').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedSize = btn.dataset.size;
      detailEl.querySelectorAll('.size-option').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
    });
  });

  // Quantity controls
  document.getElementById('qtyDecrease')?.addEventListener('click', () => {
    if (selectedQuantity > 1) {
      selectedQuantity--;
      document.getElementById('qtyInput').value = selectedQuantity;
    }
  });

  document.getElementById('qtyIncrease')?.addEventListener('click', () => {
    if (selectedQuantity < 10) {
      selectedQuantity++;
      document.getElementById('qtyInput').value = selectedQuantity;
    }
  });

  // Add to Cart
  document.getElementById('detailAddToCart')?.addEventListener('click', () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      size: selectedSize,
      quantity: selectedQuantity,
      image: product.images[0]
    });
  });

  // Buy Now
  document.getElementById('detailBuyNow')?.addEventListener('click', () => {
    closeProductModal();
    openCheckout({
      id: product.id,
      name: product.name,
      price: product.price,
      size: selectedSize,
      quantity: selectedQuantity,
      image: product.images[0]
    });
  });

  const modal = document.getElementById('productModal');
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}

/**
 * Close product detail modal
 */
function closeProductModal() {
  const modal = document.getElementById('productModal');
  modal.hidden = true;
  currentProduct = null;
  if (!isAnyModalOpen()) {
    document.body.style.overflow = '';
  }
}

// ==========================================
// MODAL MANAGEMENT
// ==========================================

/**
 * Close all modals
 */
function closeAllModals() {
  document.querySelectorAll('.modal').forEach(modal => {
    modal.hidden = true;
  });
  document.body.style.overflow = '';
}

/**
 * Initialize modal close handlers
 */
function initModals() {
  document.querySelectorAll('[data-close-modal]').forEach(el => {
    el.addEventListener('click', () => {
      const modal = el.closest('.modal');
      if (modal) {
        modal.hidden = true;
        if (!isAnyModalOpen()) {
          document.body.style.overflow = '';
        }
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
      closeCart();
    }
  });
}

// ==========================================
// NAVIGATION
// ==========================================

/**
 * Initialize smooth scroll navigation
 */
function initNavigation() {
  const header = document.getElementById('header');
  const nav = document.getElementById('nav');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.querySelectorAll('.nav__link');

  // Header scroll effect
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 20);
    updateActiveNavLink();
  }, { passive: true });

  // Mobile nav toggle
  navToggle?.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    navToggle.classList.toggle('active', isOpen);
    navToggle.setAttribute('aria-expanded', isOpen);
  });

  // Smooth scroll for all anchor links
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const targetId = link.getAttribute('href');
      if (targetId === '#') return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        const offset = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-height'), 10) || 72;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });

        // Close mobile nav
        nav?.classList.remove('open');
        navToggle?.classList.remove('active');
        navToggle?.setAttribute('aria-expanded', 'false');
      }
    });
  });

  // Update active nav link on click
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
}

/**
 * Highlight active nav link based on scroll position
 */
function updateActiveNavLink() {
  const sections = ['home', 'collections', 'contact'];
  const headerHeight = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-height'), 10) || 72;
  let current = 'home';

  sections.forEach(id => {
    const section = document.getElementById(id);
    if (section) {
      const top = section.offsetTop - headerHeight - 100;
      if (window.scrollY >= top) {
        current = id;
      }
    }
  });

  document.querySelectorAll('.nav__link').forEach(link => {
    link.classList.toggle('active', link.dataset.section === current);
  });
}

// ==========================================
// SEARCH & FILTERS
// ==========================================

/**
 * Initialize search and category filter controls
 */
function initSearchAndFilters() {
  const searchInput = document.getElementById('searchInput');
  const searchClear = document.getElementById('searchClear');
  const filters = document.getElementById('categoryFilters');

  let debounceTimer;

  searchInput?.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      searchQuery = searchInput.value;
      searchClear.hidden = !searchQuery;
      renderProducts();
    }, 250);
  });

  searchClear?.addEventListener('click', () => {
    searchInput.value = '';
    searchQuery = '';
    searchClear.hidden = true;
    renderProducts();
    searchInput.focus();
  });

  filters?.querySelectorAll('.category-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      activeCategory = btn.dataset.category;
      filters.querySelectorAll('.category-filter').forEach(b => {
        b.classList.toggle('active', b === btn);
        b.setAttribute('aria-selected', b === btn);
      });
      renderProducts();
    });
  });
}

// ==========================================
// CONTACT FORM
// ==========================================

/**
 * Initialize contact form with validation
 */
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let valid = true;

    const fields = {
      contactName: { el: document.getElementById('contactName'), error: document.getElementById('contactNameError'), check: v => v.trim().length > 0, msg: 'Name is required' },
      contactEmail: { el: document.getElementById('contactEmail'), error: document.getElementById('contactEmailError'), check: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), msg: 'Valid email is required' },
      contactPhone: { el: document.getElementById('contactPhone'), error: document.getElementById('contactPhoneError'), check: v => /^[\d\s+\-()]{10,15}$/.test(v), msg: 'Valid phone number is required' },
      contactMessage: { el: document.getElementById('contactMessage'), error: document.getElementById('contactMessageError'), check: v => v.trim().length > 0, msg: 'Message is required' }
    };

    Object.values(fields).forEach(({ el, error, check, msg }) => {
      if (!check(el.value)) {
        error.textContent = msg;
        el.classList.add('error');
        valid = false;
      } else {
        error.textContent = '';
        el.classList.remove('error');
      }
    });

    if (!valid) return;

    // Future backend integration:
    // await fetch('/api/contact', { method: 'POST', body: new FormData(form) });

    const successEl = document.getElementById('contactFormSuccess');
    successEl.hidden = false;
    form.reset();
    showToast('Message sent successfully!');

    // Optionally open WhatsApp with the inquiry
    const name = fields.contactName.el.value;
    const message = fields.contactMessage.el.value;
    setTimeout(() => {
      openWhatsAppInquiry(`Hi, I'm ${name}. ${message}`);
    }, 1500);
  });

  form.querySelectorAll('input, textarea').forEach(field => {
    field.addEventListener('input', () => field.classList.remove('error'));
  });
}

// ==========================================
// SCROLL REVEAL ANIMATIONS
// ==========================================

/** Intersection Observer for reveal animations */
let revealObserver;

/**
 * Observe elements with .reveal class for scroll animations
 */
function observeRevealElements() {
  if (!revealObserver) {
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  }

  document.querySelectorAll('.reveal:not(.visible)').forEach(el => {
    revealObserver.observe(el);
  });
}

// ==========================================
// APP INITIALIZATION
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initModals();
  initCart();
  initCheckout();
  initWhatsApp();
  initSearchAndFilters();
  initContactForm();
  renderProducts();
  observeRevealElements();
});
