/**
 * Product Catalog Data
 * Ready for future backend API integration — replace PRODUCTS array with fetch call
 */

const PRODUCTS = [
  /* ---- HIJABS ---- */
  {
    id: 'hijab-001',
    name: 'Premium Chiffon Hijab',
    category: 'hijabs',
    categoryLabel: 'Hijabs',
    description: 'Lightweight, breathable chiffon hijab with a soft drape. Perfect for everyday wear and special occasions. Features non-slip inner lining.',
    price: 499,
    sizes: ['Free Size'],
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1594736797933-d0cbc0b8a6a9?w=600&h=800&fit=crop&q=80'
    ]
  },
  {
    id: 'hijab-002',
    name: 'Embroidered Silk Hijab',
    category: 'hijabs',
    categoryLabel: 'Hijabs',
    description: 'Luxurious silk hijab with delicate hand-embroidered borders. Rich texture and elegant sheen for festive celebrations.',
    price: 899,
    sizes: ['Free Size'],
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4ee8?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80'
    ]
  },

  /* ---- NIGHTIES ---- */
  {
    id: 'nightie-001',
    name: 'Cotton Floral Nightie',
    category: 'nighties',
    categoryLabel: 'Nighties',
    description: 'Soft 100% cotton nightie with a charming floral print. Relaxed fit with button-front closure for ultimate comfort.',
    price: 699,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1558171813-4c088753b845?w=600&h=800&fit=crop&q=80'
    ]
  },
  {
    id: 'nightie-002',
    name: 'Satin Lace Night Gown',
    category: 'nighties',
    categoryLabel: 'Nighties',
    description: 'Elegant satin night gown with delicate lace trim. Smooth, luxurious fabric that feels wonderful against the skin.',
    price: 1299,
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1558171813-4c088753b845?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&h=800&fit=crop&q=80'
    ]
  },

  /* ---- SAREES ---- */
  {
    id: 'saree-001',
    name: 'Banarasi Silk Saree',
    category: 'sarees',
    categoryLabel: 'Sarees',
    description: 'Exquisite Banarasi silk saree with intricate zari weaving. A timeless piece for weddings and grand celebrations.',
    price: 4999,
    sizes: ['Free Size'],
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4ee8?w=600&h=800&fit=crop&q=80'
    ]
  },
  {
    id: 'saree-002',
    name: 'Georgette Printed Saree',
    category: 'sarees',
    categoryLabel: 'Sarees',
    description: 'Lightweight georgette saree with vibrant digital prints. Easy to drape and perfect for casual and semi-formal events.',
    price: 1899,
    sizes: ['Free Size'],
    images: [
      'https://images.unsplash.com/photo-1594736797933-d0cbc0b8a6a9?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80'
    ]
  },

  /* ---- 3-PIECE SETS ---- */
  {
    id: '3piece-001',
    name: 'Embroidered 3-Piece Suit',
    category: '3_piece_sets',
    categoryLabel: '3-Piece Sets',
    description: 'Stunning 3-piece suit set with embroidered kurta, matching palazzo, and dupatta. Premium cotton blend fabric.',
    price: 2499,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4ee8?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1594736797933-d0cbc0b8a6a9?w=600&h=800&fit=crop&q=80'
    ]
  },
  {
    id: '3piece-002',
    name: 'Printed Cotton 3-Piece Set',
    category: '3_piece_sets',
    categoryLabel: '3-Piece Sets',
    description: 'Comfortable cotton 3-piece set with block-print motifs. Includes kurta, straight pants, and contrast dupatta.',
    price: 1799,
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4ee8?w=600&h=800&fit=crop&q=80'
    ]
  },

  /* ---- ANARKALIS ---- */
  {
    id: 'anarkali-001',
    name: 'Floor-Length Anarkali Gown',
    category: 'anarkalis',
    categoryLabel: 'Anarkalis',
    description: 'Regal floor-length anarkali with heavy embroidery and flowing silhouette. Ideal for weddings and festive gatherings.',
    price: 3999,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    images: [
      'https://images.unsplash.com/photo-1594736797933-d0cbc0b8a6a9?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop&q=80'
    ]
  },
  {
    id: 'anarkali-002',
    name: 'Georgette Anarkali Suit',
    category: 'anarkalis',
    categoryLabel: 'Anarkalis',
    description: 'Graceful georgette anarkali with subtle sequin work and matching churidar. Lightweight and elegant for parties.',
    price: 2799,
    sizes: ['S', 'M', 'L', 'XL'],
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4ee8?w=600&h=800&fit=crop&q=80',
      'https://images.unsplash.com/photo-1594736797933-d0cbc0b8a6a9?w=600&h=800&fit=crop&q=80'
    ]
  }
];

/** Format price in Indian Rupees */
function formatPrice(amount) {
  return '₹' + amount.toLocaleString('en-IN');
}

/** Find product by ID */
function getProductById(id) {
  return PRODUCTS.find(p => p.id === id) || null;
}

/** Filter products by category and search query */
function filterProducts(category, searchQuery) {
  let filtered = PRODUCTS;

  if (category && category !== 'all') {
    filtered = filtered.filter(p => p.category === category);
  }

  if (searchQuery && searchQuery.trim()) {
    const q = searchQuery.trim().toLowerCase();
    filtered = filtered.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.categoryLabel.toLowerCase().includes(q) ||
      p.category.replace(/_/g, ' ').includes(q)
    );
  }

  return filtered;
}
