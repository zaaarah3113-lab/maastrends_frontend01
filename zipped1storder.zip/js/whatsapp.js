/**
 * WhatsApp Integration Module
 * Configure phone number and community link below for production use.
 */

const WhatsAppConfig = {
  // Merchant WhatsApp number (with country code, no + or spaces)
  phoneNumber: '919876543210',

  // Optional: WhatsApp community/group invite link
  communityLink: '',

  // Shop name for message templates
  shopName: 'Maas Trends'
};

/**
 * Build a WhatsApp chat URL with pre-filled message
 * @param {string} message - Pre-filled message text
 * @returns {string} WhatsApp deep link URL
 */
function getWhatsAppUrl(message) {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${WhatsAppConfig.phoneNumber}?text=${encoded}`;
}

/**
 * Open WhatsApp inquiry chat
 * @param {string} [customMessage] - Optional custom message
 */
function openWhatsAppInquiry(customMessage) {
  const message = customMessage || `Hi ${WhatsAppConfig.shopName}! I'd like to inquire about your products.`;
  window.open(getWhatsAppUrl(message), '_blank', 'noopener');
}

/**
 * Open WhatsApp community/group link (falls back to inquiry chat)
 */
function openWhatsAppCommunity() {
  if (WhatsAppConfig.communityLink) {
    window.open(WhatsAppConfig.communityLink, '_blank', 'noopener');
  } else {
    openWhatsAppInquiry();
  }
}

/**
 * Build order confirmation message for WhatsApp notification
 * @param {Object} order - Order object
 * @returns {string} Formatted order message
 */
function buildOrderConfirmationMessage(order) {
  const items = order.items.map(item =>
    `• ${item.name} (Size: ${item.size}) × ${item.quantity} — ${formatPrice(item.price * item.quantity)}`
  ).join('\n');

  const address = [
    order.customer.houseNo,
    order.customer.street,
    order.customer.area,
    order.customer.city,
    order.customer.state,
    order.customer.postalCode,
    order.customer.country
  ].filter(Boolean).join(', ');

  return [
    `🛍️ *New Order — ${WhatsAppConfig.shopName}*`,
    ``,
    `*Order ID:* ${order.orderId}`,
    `*Date:* ${order.date}`,
    ``,
    `*Items:*`,
    items,
    ``,
    `*Subtotal:* ${formatPrice(order.subtotal)}`,
    `*Shipping:* ${formatPrice(order.shipping)}`,
    `*Total:* ${formatPrice(order.total)}`,
    ``,
    `*Customer Details:*`,
    `Name: ${order.customer.fullName}`,
    `Phone: ${order.customer.mobile}`,
    `Email: ${order.customer.email}`,
    `Address: ${address}`,
    order.customer.landmark ? `Landmark: ${order.customer.landmark}` : '',
    ``,
    `*Payment:* ${order.paymentMethod} — Confirmed ✅`
  ].filter(line => line !== '').join('\n');
}

/**
 * Trigger WhatsApp order confirmation workflow
 * Opens WhatsApp with order details — ready for backend webhook integration
 * @param {Object} order - Complete order object
 */
function sendOrderWhatsAppConfirmation(order) {
  const message = buildOrderConfirmationMessage(order);

  // Future backend integration point:
  // await fetch('/api/orders/whatsapp-notify', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({ orderId: order.orderId, message, customerPhone: order.customer.mobile })
  // });

  // For now, open WhatsApp with order summary (merchant receives notification)
  window.open(getWhatsAppUrl(message), '_blank', 'noopener');

  // Also prepare customer-facing confirmation message
  const customerMessage = [
    `Hi ${order.customer.fullName}! 🎉`,
    ``,
    `Your order *${order.orderId}* at ${WhatsAppConfig.shopName} has been confirmed!`,
    `Total: ${formatPrice(order.total)}`,
    ``,
    `We'll process your order and update you on delivery.`,
    `Thank you for shopping with us! 💚`
  ].join('\n');

  // Store for potential automated customer notification via backend
  order.whatsappCustomerMessage = customerMessage;
  order.whatsappMerchantMessage = message;
}

/**
 * Initialize WhatsApp floating button and contact buttons
 */
function initWhatsApp() {
  const floatBtn = document.getElementById('whatsappFloat');
  const contactBtn = document.getElementById('contactWhatsAppBtn');

  if (floatBtn) {
    floatBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openWhatsAppCommunity();
    });
  }

  if (contactBtn) {
    contactBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openWhatsAppInquiry();
    });
  }
}
